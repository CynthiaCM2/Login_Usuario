﻿using System;
using System.Collections.Generic;

namespace Login_Usuario.Models
{
    public partial class Contraseña
    {
        public int Idcontraseña { get; set; }
        public string Clave { get; set; }
    }
}
