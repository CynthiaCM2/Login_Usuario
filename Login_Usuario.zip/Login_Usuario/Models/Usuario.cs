﻿using System;
using System.Collections.Generic;

namespace Login_Usuario.Models
{
    public partial class Usuario
    {
        public int Idusuario { get; set; }
        public string Nombre { get; set; }
        public string Clave { get; set; }
    }
}
